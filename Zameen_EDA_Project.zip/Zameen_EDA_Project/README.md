**Project Name:** Zameen\_EDA\_Final   
**Dataset:** Zameen.com real estate listings (Scraped)   
**Prepared by:** Mariam Khalil 

**Project Overview:**  
This project conducts an Exploratory Data Analysis (EDA) on real estate listings scraped from \[Zameen.com\](https://www.zameen.com), Pakistan’s leading property portal. The goal is to uncover key market insights related to pricing trends, property types, buyer preferences, and outlier detection across urban and secondary cities.

**Repository Structure:**  
zameen-eda-project/   
├── data/   
│ └── Zameen.com.xlsx   
├── notebook/   
│ └── zameen\_eda\_final.ipynb   
├── outputs/   
│ └── visuals/   
├── report/   
│ └── Zameen\_EDA\_Insights\_Report.pdf   
└── README.md 

Tools & Libraries used  
**Total Entries:** 18,255   
**Total Features:** 59 

* Languages: Python    
* Libraries: Pandas, NumPy, Matplotlib, Seaborn    
* Environment: Jupyter Notebook

**Key Insights:**   
**1\. Price per Square Foot Varies Significantly by City**   
● Major cities like Lahore, Islamabad, and Karachi have the highest prices per square foot, indicating premium markets.   
● In contrast, cities like Faisalabad, Bahawalpur, and Gujrat offer much more space for the same budget.   
● This suggests that urban centers are becoming more vertically dense while secondary cities remain more spacious and affordable.   
● In primary cities, while smaller cities remain more spacious and cost-effective.   
**2\. Property Type Strongly Influences Pricing**   
● Houses generally have higher median prices than flats and portions.   
● Upper and Lower portions are consistently more affordable, likely making them attractive to middle-income families and renters.   
● Flats dominate in high-density areas like Karachi and Islamabad.   
**3\. Bedrooms Affect Price Up to a Point**   
● Properties with 2 to 4 bedrooms show a gradual price increase.   
● However, beyond 5 bedrooms, the price does not increase proportionally, indicating diminishing returns in the luxury segment.   
● This may be due to market saturation or limited demand for very large homes.   
**4\. Newer Properties Command Higher Prices**   
● A clear negative correlation was observed between Property Age and Price.   
● Newly built homes (0 \- 5 years old) attract premium pricing, especially in gated communities and newer developments.   
● Older homes (\>15 years) are often cheaper, possibly due to renovation needs or outdated construction standards. affordable, possibly due to aging infrastructure or renovation requirements.   
**5\. Significant Outliers in Raw Data**   
● Several listings had unrealistic values, such as areas over 800,000 sqft and prices in billions of PKR.   
● These outliers distorted visualizations and averages.   
● We addressed this using the IQR method to retain a clean, realistic dataset. 

**Recommendations:** 

**For Property Buyers:**   
● Consider secondary cities like Multan, Sahiwal, or Bahawalpur to get more area for a lower price.   
● If you're a first-time buyer or working with a modest budget, flats and lower/upper portions in urban centers offer better value.   
● Prioritize newer constructions for better long-term investment potential.   
**For Real Estate Agents & Sellers:**   
● Avoid vague or inflated listings (e.g., “Contact for Price”) as they often reduce listing credibility and buyer interest.   
● Use Price per Square Foot as a more accurate benchmark when listing or comparing properties.   
● Highlight listings that are recently built and located in high-demand areas which tend to perform best in terms of value.   
● Avoid listing properties with vague pricing (e.g., "Contact for Price") or inflated values, they reduce credibility.   
**For Real Estate Platforms:**   
● Implement stricter data input validation to prevent issues like inconsistent city names or unrealistic prices.   
● Enable filters for price per sqft, property age, and type, these are key decision-making factors.   
● Educate users with market benchmarks and intelligent price suggestions based on listings. 

